rootProject.name = "StockifyWebView"
include(":app")
